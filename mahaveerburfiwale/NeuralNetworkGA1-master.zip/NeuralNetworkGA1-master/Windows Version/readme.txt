Did I just create life? Crazy AI Robots!

This is an example of using genetic algorithms to evolve a neural network.

----------------------------------------------------------------------------------------
For more information about this please visit https://www.youtube.com/watch?v=bq3FdlUeOTU 
----------------------------------------------------------------------------------------


To control the simulation, look at the code towards the top of the 'simulation.h' file
This application is designed to be compiled for Visual Studio 2019 on Windows.

If you want to support my channel then consider becoming a Patreon!

Patreon: https://www.patreon.com/RobSmithDev
Discord: https://discord.gg/MKZ6HA6ZWE

Copyright © RobSmithDev 2021-2022
https://robsmithdev.co.uk